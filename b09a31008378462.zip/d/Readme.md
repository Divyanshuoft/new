CSCB07 Assignment 1 Documentation by Divyansh Kachchhava Student NUmber: 1008378462
 
 
 
Structure of the Code:
The code is modular and is divided into various functions to avoid reduplication of code and is srtucuted very clearly




Variables:
No global variable is declared
The names of the variables are descriptive and self-explanatory. The type of data stored in each variable is also specified.




Requriemnts:
The following libraries are used in the program:
#include <stdio.h>
#include <sys/utsname.h>
#include <unistd.h>
#include <sys/resource.h>
#include <utmp.h>
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>
#include <sys/sysinfo.h>




Functions:
Below are the functions which are defined in the program code 




[Function return_system_information()]:
[Description]: Return the information about the machine's name, version, release and achitecture 
    The <sys/utsname.h> header shall define the structure utsname which shall include at least the following members:
    sysname, nodename, release, version and machine which gives information about system information
    Documentation source: https://pubs.opengroup.org/onlinepubs/009695399/basedefs/sys/utsname.h.html
    Note: uname here refers to pointers and all the above members are defined as pointer nodes.
[Input]: No input required
[Output]: Return the information about the machine's name, version, release and achitecture to the screen 




[Function memory_usage()]:
[Description]: 
    gives the total memory utilization
    rusage data structure will allow us to handle all the parts of the CPU
    to calculate memory effectively
    Max contributor is from ru_maxrss
    Note: it's in the integer format.
[Input]: No input required
[Output]: gives the total memory utilization output to teh screen in kilobytes




[Function error_message()]:
[Description]:    Return an output on the terminal stating that there was some issue in the code .
[Input]: [Input parameters and data type]
[Output]: an error mesage appear on the screen as an output




[Function get_cpu_usage_for_one_second()]:
[Description]: Returns the cpu usage at the exact moment
    reads the proc file and add up everthing to the total
    and returns as the result.
    Adds up all the core CUP usage values from all the cores
    total + user + nice + system + idle + iowait + irq + softirq + steal
    addding all the values, note: all are in float
[Input]:  No input required
[Output]: Returns the cpu usage at the exact moment at the particular second




[Function graphic_for_cpu(float a, float *b, char *x)]:
[Description]: It marks the increament/decreament denoted by ||||
    It does that acc. to the relative value
    a single increament(|) denotes 10% increase
    Note: this is for case where none of a, b is zero 
    ie. This is not for the starting case.
[Input]: a and b are the 2 variables which relative value we have to compute out
	where as x is the string where we need to concatinate our result
[Output]: It gives the symbolic increase/decrease in terms of the change in the relative values on the screen




[Function graphic_for_cpu_2(float a, char *p, char *x)]:
[Description]: It marks the increament/decreament denoted by ||||
    It does that acc. to the relative value
    a single increament(|) denotes 10% increase
    Note: this is for case where a, b is zero 
    ie. This is for the starting case.
[Input]: a and b are the 2 variables which relative value we have to compute out
	where as x is the string where we need to concatinate our result
[Output]: It gives the symbolic increase/decrease in terms of the change in the relative values on the screen





[Function subtract_after_sleep(float *c, float *a)]:
[Description]: Return the diff of the a and b cpu usages to 
    get the relative differnce betwen the two.
[Input]: a and c are the variales with which we want to compute the differnce in 1 second sleep
[Output]: We get the relative change in the values as a result





[Function find_cpu_usage()]:
[Description]: Returns the total cpu usage for the system
    It get's total means that you consider the load across all cores 
    and then it take samples at two separate point (seperated by a gap of 1 second)
    in time and compare them making relative to the first sample
    I believe that there will always be 10. They represent the following:
    user, nice,system, idle, iowait, irq, softirq, steal, guest and guest_nice
    We'll be totalling every thing except guest and guest_nice becuase they are
    included in the user and nice value outputs.
    Note: we'll use the absolute value of the total cpu usage because the 
    relative change may be positive or negative.
    For the version: I've choosen the base point as 0 so the starting value of the
    CPU usage will be 0.00 by which it will be easier to carry out operations
    and find the relative change.

[Input]:  No input required
[Output]: Returns the total cpu usage for the systea as an output to the screen





[Function get_session_info()]:
[Description]: 
    It wll give the information about the users and the sessions 
    The utmp pointer consists of the following fields,
    ut_line for the Device name
    ut_id for the Terminal name
    ut_user for the Username
    ut_host for the Hostname 
    format: username, device name, terminal name
[Input]:  No input required
[Output]:  It wll give the information about the users and the sessions to the screen as an output





[Function cal_per(float a, float b, char *new)]:
[Description]: It add on the increament/decreament acc. to the relative value 
    diff: relative value of a and b in percentage form
    : when there's a decreament
    # when there's an increament 
[Input]: a and ba re the value with which we need to compare and indicate the change
	new is the string with which we need to concatinate our answer to
[Output]: It'll concatinate with new to give a graphical representation of the change as as output





[Function get_cpu_utilization(int N, int T, char array[N][1024], int index, float matrix[N])]:
[Description]: 
	### For graphic CPU utilization output
	### intended to see the increament and decreament signs
    It's gives the total cpu usage by aall the cores combined
    It's given by in-class formula
    	Representation: (Phys.Used/Tot -- Virtual Used/Tot)
    	where, Phy.Used means used physical usage, Vir Used means used virtual usage
    	and Tot means thte total storage in the CPU
    We are taking N sample in every T seconds which are given in the arguement
    if not given, default N = 10 and T = 1
    	The size can be changed
    The index maintain the index of main itteration 
    The representation of the change is displayed in terms if # for increase ot : for decrease
[Input]: 
	N: the sample size
	T: frequency to take the samples
	The array to access and store the memory usages
	Current index of the itteration in int format
	The matrix to store the increament and decreament values temperorily
[Output]:
	Prints the the memory used in Phys.Used/Tot -- Virtual Used/Tot format
	Also gives the graphi dsiplay of the change in physical active memory
	





[Function get_cpu_utilization_2()]:
[Description]: 
	### For non-graphic CPU utilization output
	### Not-intended to see the increament and decreament signs
    It's gives the total cpu usage by aall the cores combined
    It's given by in-class formula
    	Representation: (Phys.Used/Tot -- Virtual Used/Tot)
    	where, Phy.Used means used physical usage, Vir Used means used virtual usage
    	and Tot means thte total storage in the CPU
    We are taking N sample in every T seconds which are given in the arguement
    if not given, default N = 10 and T = 1
    	The size can be changed
    The index maintain the index of main itteration 
[Input]: 
	N: the sample size
	T: frequency to take the samples
	The array to access and store the memory usages
	Current index of the itteration in int format
[Output]:
	Prints the the memory used in Phys.Used/Tot -- Virtual Used/Tot format

[Function get_cpu_utilization_2()]:
[Description]: 
	### For non-graphic CPU utilization output
	### Not-intended to see the increament and decreament signs
    It's gives the total cpu usage by aall the cores combined
    It's given by in-class formula
    	Representation: (Phys.Used/Tot -- Virtual Used/Tot)
    	where, Phy.Used means used physical usage, Vir Used means used virtual usage
    	and Tot means thte total storage in the CPU
    We are taking N sample in every T seconds which are given in the arguement
    if not given, default N = 10 and T = 1
    	The size can be changed
    The index maintain the index of main itteration 
[Input]: 
	N: the sample size
	T: frequency to take the samples
	The array to access and store the memory usages
	Current index of the itteration in int format
[Output]:
	Prints the the memory used in Phys.Used/Tot -- Virtual Used/Tot format






Why I'm right?





--> Finding CPU usage: I used the formula given by our TA which was  
    double totald = (double) total_cur - (double) total_prev;
    double idled = (double) idle_cur - (double) idle_prev;

    double cpu_perc = (1000 * (totald - idled) / totald + 1) / 10;
    
    where cpu_perc will be our cpu usage. 
    
    Note: Ideal CPU total usage is the storage which is idle which means not in use
    whereas we need to find the active cpu usage will be our result.
    I think Iit's right because of the total value, if we subract we'll get the active running time CPU which the acccurat one
    furthermore, I think that the change in CPU values will indicate the percentage change which is reflected in the graphics.
    
    
    
    
--> How I found the memory usage, I found it by adding all the elements in the pointer field of r_usage. The maximum contribution was by maxrss field

    which was r_usage.ru_maxrss + r_usage.ru_minflt + r_usage.ru_ixrss + \
    r_usage.ru_isrss + r_usage.ru_idrss + r_usage.ru_majflt + r_usage.ru_nswap + r_usage.ru_inblock + \
    r_usage.ru_oublock + r_usage.ru_msgsnd + r_usage.ru_msgrcv + r_usage.ru_nsignals + r_usage.ru_nvcsw + r_usage.ru_nivcsw
    
    
    
    
    
--> Memory: to find the memory, I used 2 components the physical usage and the virtual usage
    physical usage: memory_info.totalram - memory_info.freeram which gives us the current running time value of the usage
    virutal usage: memory_info.totalram + memory_info.totalswap - (memory_info.freeram + memory_info.freeswap) because we need the active usage so we can ignore the free time storage
    similary, I found the total virtual and physical storage by using this formula
        float total_memory = memory_info.totalram;
    	total_memory += memory_info.totalswap;
    	total_memory *= memory_info.mem_unit;
    	float total_virtual_memory = total_memory / (1024 * 1024 * 1024);



How I'm using Piping and why my processes are concurrnet?

I pass the arguement and fork 3 times for each of the 3 processes in which we are supposed to find the solution then I wait for the children process to complete.
For the inter-process communication, I use the pipes to commmunicate in between and then I read from the child and write from the parent and I've all of my 3 processes concurrent including the memory, the cpu and the session/users

How to run the code?
Type the command make in the terminal in which the file exists then type ./b09a3 to execute and type the fals as arguements beside hte argc
Modes: use normally without any additional command arguement, use with sequential to print everything such that it appears all together, user mode which gives information about the users, 
the graphic mode which gives the informaion about eh change of increament or decreament. Works for --user command to print all the users and --system to print th ecpu usage and memory usage
