#include <stdio.h>
#include <signal.h>
#include <sys/utsname.h>
#include <unistd.h>
#include <sys/resource.h>
#include <utmp.h>
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>
#include <sys/sysinfo.h>
#include <errno.h>
#include <sys/wait.h>

#include "b09a3.h"

void call_user(int N, int T, int user, int system, int sequence, int graphic)
//It's for the user flag
{
    int mem_usage = memory_usage();
    char info_array[N][1024];
    int session_fd[2]; // file descriptors for the pipe  
    int status;
    for(int i = 0; i < N; i++){
        strcpy(info_array[i], "\n");
    }
    char store[N][1024];
    for(int i = 0; i < N; i++){
        strcpy(store[i], "\n");
    }
    for(int i = 0; i < N; i++){
        printf("\033[2J"); // Clear the screen
        printf("\033[%d;%dH", 0, 0); // Move cursor back to top-left corner
        printf("Nbr of samples: %d -- every %d secs\n", N, T);
        printf(" Memory usage: %d kilobytes\n", mem_usage);
        // Create the pipe
        if (pipe(session_fd) == -1) {
        perror("pipe");
        return;}
        //Session/user information part
        /*
        Returns the information about all the user and the sessions  for this machine
        */
        // Memory usage process
        //FORK 2
        // User session information process
        pid_t pid_sess = fork();
        if (pid_sess == 0) {
            // Child process for user session information
            close(session_fd[1]); // close the write end of the pipe
            char buf[1024];
            ssize_t n = read(session_fd[0], buf, sizeof(buf)); // read from the pipe
            if (n == -1) {
                perror("error");
            }
            printf("%s", buf);
            close(session_fd[0]); // close the read end of the pipe
            exit(0);
        } else if (pid_sess < 0) {
            // Error occurred
            perror("fork");
            exit(1);
        }
        else{
            close(session_fd[0]);
            char cpu[2][1024];
            strcpy(cpu[0], "");
            strcpy(cpu[1], "");
            get_session_info2(cpu);
            char x[1024];
            strcpy(x, "");
            strcpy(x, cpu[0]);
            ssize_t n = write(session_fd[1], x, sizeof(x)); // write to the pipe
            if (n == -1) {
                perror("write");
            }
            close(session_fd[1]); // close the write end of the pipe
        }
        waitpid(pid_sess, &status, 0); // wait for the child process to finish
        // System information part
        /*
        Return the information about the machine's name, version, release and architecture 
        */
        sleep(T);
    }
    return_system_information();
}

void call_system(int N, int T, int user, int system, int sequence, int graphic)
// It's for the system printing
{
    float k2 = 0;
    float *z = &k2;
    char info_array[N][1024];
    for(int i = 0; i < N; i++){
        strcpy(info_array[i], "\n");
    }
        int mem_usage = memory_usage();
    for(int i = 0; i < N; i++){
        if(*z < 0) *z = -*z;
        //Print statements for the headline part
        printf("\033[2J"); // Clear the screen
        printf("\033[%d;%dH", 0, 0); // Cursor goes to top-left
        printf("Nbr of samples: %d -- every %d secs\n", N, T);
        printf(" Memory usage: %d kilobytes\n", mem_usage);
        printf("---------------------------------------\n");
        printf("### Memory ### (Phys.Used/Tot -- Virtual Used/Tot)\n");  

        //Returns the memory used in Phys.Used/Tot -- Virtual Used/Tot format
        
        get_cpu_utilization_2(N, T, info_array, i);
        
        //Itterating through the values of memory usage 
        for(int i = 0; i < N; i++){
            printf("%s", info_array[i]);}

        //Session/user information part
        /*
        Returns the information about all the user and the sessions  for this machine
        */

        //Core number and CPU usage part
        /*
        Returns the number of cores present in our machine
        */
        number_of_cores();
        
        /*
        Returns the total cpu usage for the system
        */
                if(*z < 0) *z = -*z;

        printf(" total cpu use = %.2f%%\n", *z);

        //Updation of the value of CPU usage so that it can be used in next itteration
        
        *z = find_cpu_usage(T);
            if(*z < 0) *z = -*z;
    }

    //System Information part
    /*
    Return the information about the machine's name, version, release and achitecture 
    */
    return_system_information();
}
void call_sequence(int N, int T, int user, int system, int sequence, int graphic)
// It's for printing sequentail output
{
    float k = 0;
    float *z1 = &k;
    float matrix[N];
    int memory_fd[2]; // file descriptors for the pipe  
    int session_fd[2]; // file descriptors for the pipe  
    int cpu_fd[2]; // file descriptors for the pipe
    char temp[1024]; 
    int status;
    *z1 = find_cpu_usage(T);
            if(*z1 < 0) *z1 = -*z1;
    char store[N][1024];
    for(int i = 0; i < N; i++){
        strcpy(store[i], "\n");
    }
    //increament of k to avoid reduplcation  of code
    //acceptance of the command arguements
    char info_array[N][1024];
    for(int i = 0; i < N; i++){
        strcpy(info_array[i], "\n");
    }

    //memory usage for dsiplay stored in variable for later use
    int mem_usage = memory_usage();
    float ke = 0;
    float *z = &ke;

    for(int i = 0; i < N; i++){
        // Create the pipe
        if (pipe(memory_fd) == -1 || pipe(session_fd) == -1 || pipe(cpu_fd) == -1) {
            perror("pipe");
            return;}
        for(int i = 0; i < N; i++){
            strcpy(info_array[i], "\n");
        }
        if(*z < 0) *z = -*z;
        printf("\033[2J"); // C`lear the screen
        printf("\033[%d;%dH", 0, 0); // Move cursor back to top-left corner

        //To show the current itteration number, it goes uptill N-1
        printf("---------------------------------------\n");
        printf(">>> iteration %d\n", i);
        //use of memory_usage
        printf(" Memory usage: %d kilobytes\n", mem_usage);
        if(user == 0){
            printf("---------------------------------------\n");
            if(graphic == 0){
        //FORK 1
        // Memory usage process
        pid_t pid_mem = fork();
        if (pid_mem == 0) {
            close(memory_fd[1]); // close the write end of the pipe
            // Child process for memory usage
            printf("### Memory ### (Phys.Used/Tot -- Virtual Used/Tot)\n");
            // Store the value of i as the element at index i in info_array
            // get_cpu_utilization_2(N, T, info_array, i);
            // strcpy(temp, info_array[i]);
            char buf[1024];
            ssize_t n = read(memory_fd[0], buf, sizeof(buf)); // read from the pipe
            for(int k = 0; k < N; k++){
                strcpy(info_array[k], "");
            }
            strcpy(info_array[i], buf);
            for(int k = 0; k < N; k++){
                printf("%s", info_array[k]);
            }
            if (n == -1) {
                perror("read");
                exit(1);
            }
            close(memory_fd[0]); // close the read end of the pipe
            exit(0);
        } else if (pid_mem < 0) {
            // Error occurred
            perror("fork");
            exit(1);
        } else {
            // Parent process
            close(memory_fd[0]); // close the read end of the pipe
            get_cpu_utilization_2(N, T, info_array, i);
            strcpy(temp, info_array[i]);
            ssize_t n = write(memory_fd[1], temp, sizeof(temp)); // write to the pipe
            if (n == -1) {
                perror("write");
                exit(1);
            }
            close(memory_fd[1]); // close the write end of the pipe
        }
        }
        else{
            printf("### Memory ### (Phys.Used/Tot -- Virtual Used/Tot)\n"); 
            for(int i = 0; i < N; i++){
            strcpy(info_array[i], "\n");}
            get_cpu_utilization(N, T, info_array, i, matrix);

            for(int i = 0; i < N; i++){
            printf("%s", info_array[i]);
        }
        }
            
        //Session/user information part
        /*
        Returns the information about all the user and the sessions  for this machine
        */}
        if(system == 0){
        pid_t pid_sess = fork();
        if (pid_sess == 0) {
            // Child process for user session information
            close(session_fd[1]); // close the write end of the pipe
            char buf[1024];
            ssize_t n = read(session_fd[0], buf, sizeof(buf)); // read from the pipe
            if (n == -1) {
                perror("error");
            }
            printf("%s", buf);
            close(session_fd[0]); // close the read end of the pipe
            exit(0);
        } else if (pid_sess < 0) {
            // Error occurred
            perror("fork");
            exit(1);
        }
        else{
            close(session_fd[0]);
            char cpu[2][1024];
            strcpy(cpu[0], "");
            strcpy(cpu[1], "");
            get_session_info2(cpu);
            char x[1024];
            strcpy(x, "");
            strcpy(x, cpu[0]);
            strcat(x, "--------------------------------------\n");
            ssize_t n = write(session_fd[1], x, sizeof(x)); // write to the pipe
            if (n == -1) {
                perror("write");
            }
            close(session_fd[1]); // close the write end of the pipe
        }
        waitpid(pid_sess, &status, 0);
        }
        //Core number and CPU usage part
        /*
        Returns the number of cores present in our machine
        */
        if(graphic == 0){
        //FORK 3
        // CPU usage process
        pid_t pid_cpu;
        pid_cpu = fork();
        if (pid_cpu == 0) {
            // Child process for CPU usage
            close(cpu_fd[1]); // close the write end of the pipe
            char buf[1024];
            ssize_t n = read(cpu_fd[0], buf, sizeof(buf)); // read from the pipe
            if (n == -1) {
                perror("error");
            }
            printf(" total cpu usage: %s%%\n", buf);
            exit(0);
        } else if (pid_cpu < 0) {
            // Error occurred
            perror("fork");
            exit(1);
        } else {
            // Parent process
            char cpu[50];
            char x[2][1024];
            strcpy(x[0], "");
            strcpy(x[1], "");
            number_of_cores2(x);
            printf("Number of cores: %s", x[0]);
            float cpu_usage = find_cpu_usage(T);
            if (cpu_usage < 0) {
                cpu_usage = -cpu_usage;
            }
            if (cpu_usage == -0) {
                cpu_usage = 0;
            }
            sprintf(cpu, "%.2f", cpu_usage);
            close(cpu_fd[0]); // close the read end of the pipe
            ssize_t n = write(cpu_fd[1], cpu, sizeof(cpu)); // write to the pipe
            if (n == -1) {
                perror("write");
                exit(1);
            }
            close(cpu_fd[1]); // close the write end of the pipe
        }
        waitpid(pid_cpu, NULL, 0);
        }
        else{
                            if(*z < 0) *z = -*z;
        printf(" total cpu use = %.2f%%\n", *z);

        //set-up for the cpu utilization method
        char storage[1024] = "";
        char value[1024] = "";
        char x[28] = "";
                    if(*z <= 0) *z = -*z;

        strcat(x, "         |");
        sprintf(value, "%.2f", *z);
        strcat(x, storage);

        //Case when i equals 0 so we'll consider it as a base case and will represent the thing by a mark 
        if(i == 0){
            graphic_for_cpu_2(*z, 0, x);
        }
        if(i == 1){
            graphic_for_cpu_2(*z, 0, x);
        }
        
        //Case when i not equals 0 so we'll have the cpu_usage value of previous function
        /*
        Prev represents the cpu usage from previous itteration and z represent of current itteration
        */
                        if(*z < 0) *z = -*z;
        if(i > 1){
                if(*z <=0) *z = -*z;
        graphic_for_cpu_2(*z, 0, x);}

        for(int y = 0; y < i; y++){
        strcpy(store[y], "\n");}

        strcat(x, value);
        strcat(x, "\n");
        strcpy(store[i], x);

        //Itteration through every itteration where cpu usage of every itteration is stored
        for(int y = 0; y <= i; y++){
        printf("%s", store[y]);}
        
        /*
        Returns the total cpu usage for the system
        */
        *z = find_cpu_usage(T);
        }
        usleep(T * 500000); // sleep for half a second`
        }
        return_system_information();
        //sleeping for T seconds
}

void call_graphic(int N, int T, int user, int system, int sequence, int graphic)
{
    float b = 0;
            int mem_usage = memory_usage();
    float *z = &b;
    float matrix[N];
            *z = find_cpu_usage(T);
            if(*z < 0) *z = -*z;
    char info_array[N][1024];
    for(int i = 0; i < N; i++){
        strcpy(info_array[i], "\n");
    }
    char store[N][1024];
    for(int i = 0; i < N; i++){
        strcpy(store[i], "\n");
    }
    for(int i = 0; i < N; i++){
        printf("\033[2J"); // Clear the screen
        printf("\033[%d;%dH", 0, 0); // Move cursor back to top-left corner
        printf("Nbr of samples: %d -- every %d secs\n", N, T);
        printf(" Memory usage: %d kilobytes\n", mem_usage);
        if(user == 0){
        printf("---------------------------------------\n");
        printf("### Memory ### (Phys.Used/Tot -- Virtual Used/Tot)\n");  

        //Returns the memory used in Phys.Used/Tot -- Virtual Used/Tot format
        get_cpu_utilization(N, T, info_array, i, matrix);

        for(int i = 0; i < N; i++){
            printf("%s", info_array[i]);}}
        if(user == 1 && system == 1){{
        printf("---------------------------------------\n");
        printf("### Memory ### (Phys.Used/Tot -- Virtual Used/Tot)\n");  

        //Returns the memory used in Phys.Used/Tot -- Virtual Used/Tot format
        get_cpu_utilization(N, T, info_array, i, matrix);

        for(int i = 0; i < N; i++){
            printf("%s", info_array[i]);}}  
        }

        //Session/user information part
        /*
        Returns the information about all the user and the sessions  for this machine
        */
       if(system == 0 && user == 1){
        get_session_info();}
       if(system == 1 && user == 1){
        get_session_info();}
        
        //Core number and CPU usage part
        /*
        Returns the number of cores present in our machine 
        */
        number_of_cores();

        /*
        Returns the total cpu usage for the system
        Note: Here | refers to to 10 % change in the value
        Eg, if a number changes from 30 to 60 it's a 100% increase
        which signifies 10 | in the the code
        Note: | is always at the starting which shows the boundary line
        ignore the first |
        */
                if(*z < 0) *z = -*z;
        printf(" total cpu use = %.2f%%\n", *z);

        //set-up for the cpu utilization method
        char storage[1024] = "";
        char value[1024] = "";
        char x[28] = "";
                    if(*z <= 0) *z = -*z;

        strcat(x, "         |");
        sprintf(value, "%.2f", *z);
        strcat(x, storage);

        //Case when i equals 0 so we'll consider it as a base case and will represent the thing by a mark 
        if(i == 0){
            graphic_for_cpu_2(*z, 0, x);
        }
        if(i == 1){
            graphic_for_cpu_2(*z, 0, x);
        }
        
        //Case when i not equals 0 so we'll have the cpu_usage value of previous function
        /*
        Prev represents the cpu usage from previous itteration and z represent of current itteration
        */
                        if(*z < 0) *z = -*z;
        if(i > 1){
                if(*z <=0) *z = -*z;
        graphic_for_cpu_2(*z, 0, x);}

        strcat(x, value);
        strcat(x, "\n");
        strcpy(store[i], x);

        //Itteration through every itteration where cpu usage of every itteration is stored
        for(int y = 0; y <= i; y++){
        printf("%s", store[y]);}
        
        /*
        Returns the total cpu usage for the system
        */
        *z = find_cpu_usage(T);
        usleep(T * 500000); // sleep for half a second`
    }

    //System Information part
    /*
    Return the information about the machine's name, version, release and achitecture 
    */
   return_system_information();
}

void call_for_nothing(int N, int T, int user, int system, int sequence, int graphic, char info_array[N][1024]) {
    /*prints information when argc == 1*/
    for(int hg = 0; hg < N; hg++){
        strcpy(info_array[hg], "\n");
    }
    for (int i = 0; i < N; i++) {
        int memory_fd[2]; // file descriptors for the pipe  
        int session_fd[2]; // file descriptors for the pipe  
        int cpu_fd[2]; // file descriptors for the pipe
        char temp[1024]; 
        // Create the pipe
        if (pipe(memory_fd) == -1 || pipe(session_fd) == -1 || pipe(cpu_fd) == -1) {
            perror("pipe");
            return;}


        //FORK 1
        // Memory usage process
        pid_t pid_mem = fork();
        if (pid_mem == 0) {
            close(memory_fd[1]); // close the write end of the pipe
            // Child process for memory usage
            int mem_usage = memory_usage();
            printf("\033[2J"); // Clear the screen
            printf("\033[%d;%dH", 0, 0); // Cursor goes to top-left
            printf("Number of samples: %d -- every %d secs\n", N, T);
            printf("Memory usage: %d kilobytes\n", mem_usage);
            printf("---------------------------------------\n");
            printf("### Memory ### (Phys.Used/Tot -- Virtual Used/Tot)\n");
            // Store the value of i as the element at index i in info_array
            // get_cpu_utilization_2(N, T, info_array, i);
            // strcpy(temp, info_array[i]);
            char buf[1024];
            ssize_t n = read(memory_fd[0], buf, sizeof(buf)); // read from the pipe
            strcpy(info_array[i], buf);
            for(int k = 0; k < N; k++){
                printf("%s", info_array[k]);
            }
            if (n == -1) {
                perror("read");
                exit(1);
            }
            close(memory_fd[0]); // close the read end of the pipe
            exit(0);
        } else if (pid_mem < 0) {
            // Error occurred
            perror("fork");
            exit(1);
        } else {
            // Parent process
            close(memory_fd[0]); // close the read end of the pipe
            get_cpu_utilization_2(N, T, info_array, i);
            strcpy(temp, info_array[i]);
            ssize_t n = write(memory_fd[1], temp, sizeof(temp)); // write to the pipe
            if (n == -1) {
                perror("write");
                exit(1);
            }
            close(memory_fd[1]); // close the write end of the pipe
        }


        
        //FORK 2
        // User session information process
        pid_t pid_sess = fork();
        if (pid_sess == 0) {
            // Child process for user session information
            close(session_fd[1]); // close the write end of the pipe
            char buf[1024];
            ssize_t n = read(session_fd[0], buf, sizeof(buf)); // read from the pipe
            if (n == -1) {
                perror("error");
            }
            printf("%s\n", buf);
            close(session_fd[0]); // close the read end of the pipe
            exit(0);
        } else if (pid_sess < 0) {
            // Error occurred
            perror("fork");
            exit(1);
        }
        else{
            waitpid(pid_mem, NULL, 0);
            close(session_fd[0]);
            char cpu[2][1024];
            strcpy(cpu[0], "");
            strcpy(cpu[1], "");
            get_session_info2(cpu);
            char x[1024];
            strcpy(x, "");
            strcpy(x, cpu[0]);
            strcat(x, "--------------------------------------");
            ssize_t n = write(session_fd[1], x, sizeof(x)); // write to the pipe
            if (n == -1) {
                perror("write");
            }
            close(session_fd[1]); // close the write end of the pipe
        }
        
        
        //FORK 3
        // CPU usage process
        pid_t pid_cpu;
        pid_cpu = fork();
        if (pid_cpu == 0) {
            // Child process for CPU usage
            close(cpu_fd[1]); // close the write end of the pipe
            char buf[1024];
            ssize_t n = read(cpu_fd[0], buf, sizeof(buf)); // read from the pipe
            if (n == -1) {
                perror("error");
            }
            printf(" total cpu usage: %s%%\n", buf);
            exit(0);
        } else if (pid_cpu < 0) {
            // Error occurred
            perror("fork");
            exit(1);
        } else {
            // Parent process
            waitpid(pid_sess, NULL, 0);
            char cpu[50];
            char x[2][1024];
            strcpy(x[0], "");
            strcpy(x[1], "");
            number_of_cores2(x);
            printf("Number of cores: %s", x[0]);
            float cpu_usage = find_cpu_usage(T);
            if (cpu_usage < 0) {
                cpu_usage = -cpu_usage;
            }
            if (cpu_usage == -0) {
                cpu_usage = 0;
            }
            sprintf(cpu, "%.2f", cpu_usage);
            close(cpu_fd[0]); // close the read end of the pipe
            ssize_t n = write(cpu_fd[1], cpu, sizeof(cpu)); // write to the pipe
            if (n == -1) {
                perror("write");
                exit(1);
            }
            close(cpu_fd[1]); // close the write end of the pipe
        }
        waitpid(pid_cpu, NULL, 0);
    // Wait for child processes to finish
    // Sleep for T seconds
    usleep(T * 500000); // sleep for half a second
    }
}

void normal_execution(int N, int T, int user, int system, int sequence, int graphic){
    char info_array[N][1024];
    for(int i = 0; i < N; i++){
        strcpy(info_array[i], "\n");
    }
    call_for_nothing(N, T, user, system, sequence, graphic, info_array);
    return_system_information();    
}

void call_function(int N, int T, int user, int system, int sequence, int graphic){
    /*
    This function is called by the main function
    It's the main function*/
    if(user == 1){
        if(sequence == 0 && system == 0 && graphic == 0){
        call_user(N, T, user, system, sequence, graphic);}
    }
    if(system == 1){
        if(sequence == 0 && user == 0 && graphic == 0){
        call_system(N, T, user, system, sequence, graphic);}
    }
    if(sequence == 1){
        int k = 0;
        if(user == 1 && system == 1) k++;
        if(k == 0){
        call_sequence(N, T, user, system, sequence, graphic);}
        if(k!=0){
            user  = 0;
            system = 0;
            call_sequence(N, T, user, system, sequence, graphic);
            exit(0);
        }
    }
    if(graphic == 1 && sequence != 1){
        call_graphic(N, T, user, system, sequence, graphic);
    }
    if((user == 0 && system == 0 && sequence == 0 && graphic == 0) || (user == 1 && system == 1 && sequence == 0 && graphic == 0)){
        normal_execution(N, T, user, system, sequence, graphic);
    }
}

// Define signal handlers
void sigint_handler(int signum) {
    // Handle the Ctrl-C signal
    // Ask the user if they want to quit
    // If yes, then exit the program
    // If no, then continue the program
    // As per the assignment, we should ask the user if they want to quit
    char choice;
    printf("Are you sure, you want to quit? (y/n) ");
    scanf(" %c", &choice);
    if (choice == 'y' || choice == 'Y' || strcmp(&choice,"yes") == 0 || strcmp(&choice, "Yes") == 0) {
        exit(0);
    }
}

void sigtstp_handler(int signum) {
    // Ignore the Ctrl-Z signal
    // As per the assignment, we should ignore this signal
    printf("Ctrl + Z is ignored\n"); 
    return;
}

int main(int argc, char *argv[])
{   
    // Register signal handlers
    /*
    The below two lines of code are used to handle the signals
    */
    signal(SIGINT, sigint_handler);//SIGINT is the signal for Ctrl-C
    signal(SIGTSTP, sigtstp_handler);//SIGTSTP is the signal for Ctrl-Z

    int N = 10;
    int T = 1;
    
    int user = 0;
    int system = 0;
    int sequence = 0;
    int graphic = 0;

    if(argc > 1){

    for(int i = 0; i < argc; i++){
        if(strncmp(argv[i], "--tdelay=", 9) == 0){
            sscanf(argv[i], "--tdelay=%d", &T);
        }
        if(strncmp(argv[i], "--samples=", 9) == 0){
            sscanf(argv[i], "--samples=%d", &N);
        }
    }}

    if (argc > 1) {
        for(int i = 1; i < argc; i++){
            if (sscanf(argv[i], "%d", &N) == 1){
                if(i+1 < argc && sscanf(argv[i+1], "%d", &T) == 1) break;
            }
        }
    }

    if(argc > 1){
        for(int i = 0; i < argc; i++){
        if(strcmp(argv[i], "--system") == 0) system = 1;
        if(strcmp(argv[i], "--user") == 0) user = 1;
        if(strcmp(argv[i], "--graphics") == 0 || strcmp(argv[i], "-g") == 0) graphic = 1;
        if(strcmp(argv[i], "--sequential") == 0) sequence = 1;
        }
    }
    call_function(N, T, user, system, sequence, graphic);
    return 0;
}