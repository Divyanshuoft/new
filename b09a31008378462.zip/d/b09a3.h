#include "main.c"
#include <stdio.h>
#include <signal.h>
#include <sys/utsname.h>
#include <unistd.h>
#include <sys/resource.h>
#include <utmp.h>
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>
#include <sys/sysinfo.h>
#include <errno.h>
#include <sys/wait.h>

void return_system_information();

int memory_usage();

void error_message();


float get_cpu_usage_for_one_second(float *a);

void graphic_for_cpu(float a, float *b, char *x);
void graphic_for_cpu_2(float a, char *p, char *x);


float subtract_after_sleep(float *c, float *a, float *s, int zz);

float find_cpu_usage(int k);


void get_session_info();

void get_session_info2(char cpu[2][1024]);

void cal_per(float a, float b, char *new);

void get_cpu_utilization(int N, int T, char array[N][1024], int index, float matrix[N]);
void number_of_cores();

void number_of_cores2(char cpu[2][1024]);

void get_cpu_utilization_2(int N, int T, char array[N][1024], int index);

void call_user(int N, int T, int user, int system, int sequence, int graphic);

void call_system(int N, int T, int user, int system, int sequence, int graphic);

void call_sequence(int N, int T, int user, int system, int sequence, int graphic);

void call_graphic(int N, int T, int user, int system, int sequence, int graphic);

void call_for_nothing(int N, int T, int user, int system, int sequence, int graphic, char info_array[N][1024]);

void normal_execution(int N, int T, int user, int system, int sequence, int graphic);

void call_function(int N, int T, int user, int system, int sequence, int graphic);

// Define signal handlers
void sigint_handler(int signum);

void sigtstp_handler(int signum);

int main(int argc, char *argv[]);